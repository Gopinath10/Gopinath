﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Task10
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter first number for Addition :");
            int firstNumber = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter second number for Addition :");
            int secondNumber = Convert.ToInt32(Console.ReadLine());
            
            Assembly assembly = Assembly.LoadFrom(@"E:\Session\Gopi\Tasks\Task8\Addition\bin\Debug\Addition.dll");
            Type type = assembly.GetTypes().Where(a => a.Name == "Add").FirstOrDefault();

            MethodInfo methodInfo = type.GetMethod("AddTwoNumbers");
            var instance = Activator.CreateInstance(type);
            object output = methodInfo.Invoke(instance, new object[] { firstNumber , secondNumber });

            Console.WriteLine("Sum of {0} and {1} is {2}", firstNumber, secondNumber, output);
            Console.ReadLine();
        }
    }
}
