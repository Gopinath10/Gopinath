﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;
using Task5.Model;

namespace Task5
{
    class Program
    {
        static void Main(string[] args)
        {
            Employee emp = new Employee("1","Ram","Chennai","9959226711");

            XmlSerializer serializer = new XmlSerializer(typeof(Employee));

            string location = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location) + "\\" + "Database.xml";

            if (File.Exists(location) == false) File.Create(location).Dispose();

            using (StreamWriter writer = new StreamWriter(location))
            {
                serializer.Serialize(writer, emp);
            }

            using (StreamReader reader = new StreamReader(location))
            {
                var deserilzedObject = (Employee)serializer.Deserialize(reader);
            }

            string jsonSerialize = JsonConvert.SerializeObject(emp);
            Employee jsonDeserialize = JsonConvert.DeserializeObject<Employee>(jsonSerialize);
        }
    }
}
