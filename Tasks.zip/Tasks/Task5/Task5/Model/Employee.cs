﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Security;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualBasic;
using System.Xml.Serialization;

namespace Task5.Model
{
    public class Employee
    {
        private string mstrEmployeeID = string.Empty;
        private string mstrEmployeeName = string.Empty;
        private string mstrPhoneNumber = string.Empty;
        private string mstrAddress = string.Empty;

        public Employee(string pstrID, string pstrName, string pstrAddress, string pstrPhoneNumber)
        {
            EmployeeID = pstrID;
            EmployeeName = pstrName;
            Address = pstrAddress;
            PhoneNumber = pstrPhoneNumber;
        }

        public Employee()
        {

        }

        [XmlElement]
        public string EmployeeID
        {
            get
            {
                return mstrEmployeeID;
            }
            set
            {
                mstrEmployeeID = value;
            }
        }

        [XmlElement]
        public string EmployeeName
        {
            get
            {
                return mstrEmployeeName;
            }
            set
            {
                mstrEmployeeName = value;
            }
        }

        [XmlElement]
        public string PhoneNumber
        {
            get
            {
                return mstrPhoneNumber;
            }
            set
            {
                mstrPhoneNumber = value;
            }
        }

        [XmlElement]
        public string Address
        {
            get
            {
                return mstrAddress;
            }
            set
            {
                mstrAddress = value;
            }
        }
    }
}


