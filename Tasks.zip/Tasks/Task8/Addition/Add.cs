﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Addition
{
    public class Add
    {
        public int AddTwoNumbers(int a, int b)
        {
            return a + b;
        }
    }
}
