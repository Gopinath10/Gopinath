﻿using Addition;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task8
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter first number for Addition :");
            int firstNumber = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter second number for Addition :");
            int secondNumber = Convert.ToInt32(Console.ReadLine());

            Add add = new Add();

            Func<int, int, int> addTwoNumbersDelegate = new Func<int, int, int>(add.AddTwoNumbers);

            var outputAsync = addTwoNumbersDelegate.BeginInvoke(firstNumber, secondNumber, null, null);
            int output = addTwoNumbersDelegate.EndInvoke(outputAsync);

            Console.WriteLine("Sum of {0} and {1} is {2}", firstNumber, secondNumber, output);
            Console.ReadLine();
        }

      
    }
}
