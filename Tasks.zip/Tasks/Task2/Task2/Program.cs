﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task2
{
    class Program
    {
        static List<string> choices = new List<string>() { "1", "2", "3", "4", "5", "6" };
        static List<Department> Department = new List<Department>()
            {
                new Department() { Id =1,DepartmentName ="HR" } ,
                new Department() { Id =2,DepartmentName ="Sales" },
                new Department() { Id =3,DepartmentName ="IT" }
            };
        static void Main(string[] args)
        {

            //var a = Department.Select(aa => aa.DepartmentName).ToList();
            //var a1 = Department.Select(aa => aa.Id).ToList();
            //var a2 = Department.Where(aa => aa.DepartmentName == "Sales").ToList();

            // F10
            // F11 - All methods
            
            bool isExit = true;
            
            while (isExit)
            {
                try
                {
                    Console.WriteLine("Enter your choice :" + Environment.NewLine +
                                      "1.Add new user" + Environment.NewLine +
                                      "2.Get users by department" + Environment.NewLine +
                                      "3.Get users by salary more than 5000" + Environment.NewLine +
                                      "4.Get users by DOJ in last 30 days" + Environment.NewLine +
                                      "5.Sort list by Name" + Environment.NewLine +
                                      "6.Sort list by DOJ descending" + Environment.NewLine +
                                      "7.Exit" + Environment.NewLine);

                    var choice = Console.ReadLine();

                    if (choices.Contains(choice) && choice != "7")
                    {
                        switch (choice)
                        {
                            case "1":
                                CreateNewUser();
                                break;
                            case "2":
                                GetUsersByDepartment();
                                break;
                            case "3":
                                 GetUserBySalary();
                                break;
                            case "4":
                                GetUserByDOJ();
                                break;
                            case "5":
                                foreach (var item in Transactions.SortListByName()) Console.WriteLine(item.Name);
                                break;
                            case "6":
                                foreach (var item in Transactions.SortListByDOJ()) Console.WriteLine(item.Name);
                                break;
                        }
                    }
                    else if (choice == "7")
                    {
                        isExit = false;
                    }
                    else
                    {
                        Console.WriteLine("Please enter valid choice.");
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Exception : " + ex.Message);
                }
            }
        }

        private static void GetUserByDOJ()
        {
            List<Users> output = Transactions.GetUsersByDOJ();
            if (output.Any() == false)
            {
                Console.WriteLine("No users joined in last 30 days");
            }
            else
            {
                Console.WriteLine("OUTPUT");
                foreach (var item in output) Console.WriteLine(item.Name);
            }
        }

        private static void GetUserBySalary()
        {
            List<Users> output = Transactions.GetUsersBySalary(5000);

            if (output.Any() == false)
            {
                Console.WriteLine("No users getting salary more than 5000");
            }
            else
            {
                Console.WriteLine("OUTPUT");
                foreach (var item in output) Console.WriteLine(item.Name);
            }
        }

        private static void GetUsersByDepartment()
        {
            string dept = GetDepartmentFromUser(Department);
            List<Users> output = Transactions.GetUsersByDepartment(dept);

            if (output.Any() == false)
            {
                Console.WriteLine("No users available in the selected Department");
            }
            else
            {
                Console.WriteLine("OUTPUT");
                foreach (var item in output) Console.WriteLine(item.Name);
            }
        }

        private static void CreateNewUser()
        {
            Console.WriteLine("Enter Name :");
            string name = Console.ReadLine();
            string dept = GetDepartmentFromUser(Department);

            DateTime date = DateTime.Now.Date;
            int passcode = (new Random()).Next(1000, 9999);
            int salary = GetSalary();

            Users newUser = new Users()
            {
                Department = dept,
                DOJ = date,
                Name = name,
                Passcode = passcode,
                Salary = salary
            };

            bool isOutput = Transactions.CreateNewUser(newUser);
            Console.WriteLine("Added successfully");
        }

        private static int GetSalary()
        {
            int salary = 0;
            bool isGetSalary = true;
            while (isGetSalary)
            {
                Console.WriteLine("Enter Salary :");

                string salaryValue = Console.ReadLine();
                int output = 0;
                bool isValidSalary = int.TryParse(salaryValue, out output);
                if (isValidSalary)
                {
                    salary = Convert.ToInt32(salaryValue);
                    isGetSalary = false;
                }
                else
                {
                    Console.WriteLine("Please enter valid salary");
                }
            }

            return salary;
        }

        private static string GetDepartmentFromUser(List<Department> Department)
        {
            bool isDepartment = true;
            string dept = string.Empty;

            while (isDepartment)
            {
                Console.WriteLine("Choose Department :" + Environment.NewLine +
                                  "1.Sales" + Environment.NewLine +
                                  "2.HR" + Environment.NewLine +
                                  "3.IT");
                string deptInput = Console.ReadLine();

                if (Department.Select(a => a.Id.ToString()).Contains(deptInput))
                {
                    dept = Department.Where(a => a.Id.ToString() == deptInput).FirstOrDefault().DepartmentName; 
                    isDepartment = false;
                }
                else
                {
                    Console.WriteLine("Please choose correct department.");
                }
            }

            return dept;
        }
    }
}
