﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task2
{
    public class Transactions
    {
        public static Data AllData { get; set; } = new Data();
        public static bool CreateNewUser(Users user)
        {
            bool isSuccess = false;
            try
            {
                AllData.AllUsers.Add(user);
                isSuccess = true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return isSuccess;
        }

        public static List<Users> GetUsersByDepartment(string department)
        {
            return AllData.AllUsers.Where(a => a.Department == department).ToList();
        }

        public static List<Users> GetUsersBySalary(int salary)
        {
            return AllData.AllUsers.Where(a => a.Salary >= salary).ToList();
        }

        public static List<Users> GetUsersByDOJ()
        {
            return AllData.AllUsers.Where(a => a.DOJ >= DateTime.Today.AddDays(-30)).ToList();
        }

        public static List<Users> SortListByName()
        {
            return AllData.AllUsers.OrderBy(a => a.Name).ToList();
        }

        public static List<Users> SortListByDOJ()
        {
            return AllData.AllUsers.OrderBy (a => a.DOJ).ToList();
        }
    }
}

