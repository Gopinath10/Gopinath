﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task2
{
    public class Data
    {
        public Data()
        {
            AllUsers = new List<Users>()
            {
                new Users() { Name ="Hari",Department="Sales",DOJ=new DateTime(2018,8,21),Passcode = 1234,Salary=1250 },
                new Users() { Name ="Gokul",Department="HR",DOJ=new DateTime(2016,7,10),Passcode = 4574,Salary=2000 },
                new Users() { Name ="Ravi",Department="IT",DOJ=new DateTime(2017,8,11),Passcode = 9999,Salary=2500 },
                new Users() { Name ="Kumar",Department="Sales",DOJ=new DateTime(2015,7,21),Passcode = 8989,Salary=6000},
                new Users() { Name ="Reshma",Department="IT",DOJ=new DateTime(2016,7,21),Passcode = 3939 ,Salary=9000},
                new Users() { Name ="Revathi",Department="IT",DOJ=new DateTime(2015,5,21),Passcode = 9929 ,Salary=5500},
                new Users() { Name ="Aravind",Department="HR",DOJ=new DateTime(2017,9,2),Passcode = 1232 ,Salary=8000},
            };
        }

        private List<Users> allUsers;

        public List<Users> AllUsers
        {
            get { return allUsers; }
            set { allUsers = value; }
        }
    }
}
