﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task4
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter a string to encrypt : ");
            var input = Console.ReadLine();

            string encryptedString = EncryptionHelper.Encrypt(input);
            Console.WriteLine("Encrypted Value : {0}", encryptedString);

            string decryptedString = EncryptionHelper.Decrypt(encryptedString);
            Console.WriteLine("Decrypted Value : {0}" , decryptedString);
            
            string encodedString = EncodeDecodeHelper.Base64Encode(input);
            Console.WriteLine("Encoded Value : {0}", encodedString);

            string decodedString = EncodeDecodeHelper.Base64Decode(encodedString);
            Console.WriteLine("Decoded Value : {0}", decodedString);

            Console.ReadLine();
        }
    }
}
