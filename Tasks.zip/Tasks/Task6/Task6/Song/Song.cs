﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Task6.Interface;

namespace Task6.Song
{
    public class Song : ISong
    {
        public string SongName { get; set; }
        public string MovieName { get; set; }
        public void MoveFiveSecondsBackward()
        {
            
        }

        public void MoveFiveSecondsForward()
        {
            
        }

        public void Run()
        {
            
        }

        public void Stop()
        {
            
        }

    }
}
