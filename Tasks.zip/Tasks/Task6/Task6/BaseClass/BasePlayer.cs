﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Task6.Interface;

namespace Task6.BaseClass
{
    public abstract class BasePlayer
    {
        public BasePlayer()
        {
            Songs = new List<ISong>();
        }

        private ISong currentSong;
        private IList<ISong> songs;

        public ISong CurrentSong
        {
            get { return currentSong; }
            set { currentSong = value; }
        }

        public IList<ISong> Songs
        {
            get { return songs; }
            set { songs = value; }
        }
        
        public virtual void BaseForward(IPlayer player)
        {
            player.CurrentSong.MoveFiveSecondsForward();
        }

        public virtual void BaseAddSongs(ISong song)
        {
            Songs.Add(song);
        }

        public virtual void BaseNext(IPlayer player)
        {
            int index = player.Songs.IndexOf(player.CurrentSong);

            if (player.Songs.Count() - 1 == index)
            {
                player.CurrentSong = player.Songs.FirstOrDefault();
            }
            else
            {
                player.CurrentSong = player.Songs[index + 1];
            }
        }

        public virtual void BasePlay(IPlayer player)
        {
            if (player.CurrentSong == null) player.CurrentSong = player.Songs.FirstOrDefault();
            else player.CurrentSong.Run();
        }

        public virtual void BasePrevious(IPlayer player)
        {
            int index = player.Songs.IndexOf(player.CurrentSong);

            if (index == 0)
            {
                player.CurrentSong = player.Songs.LastOrDefault();
            }
            else
            {
                player.CurrentSong = player.Songs[index - 1];
            }
        }

        public virtual void BaseRewind(IPlayer player)
        {
            player.CurrentSong.MoveFiveSecondsBackward();
        }

        public virtual void BaseStop(IPlayer player)
        {
            player.CurrentSong.Stop();
        }
    }
}
