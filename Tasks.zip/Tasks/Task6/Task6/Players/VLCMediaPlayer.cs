﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Task6.BaseClass;
using Task6.Interface;

namespace Task6.Players
{
    public class VLCMediaPlayer : BasePlayer, IPlayer
    {
        public void AddSongs(ISong song)
        {
            BaseAddSongs(song);
        }

        public void Forward()
        {
            BaseForward(this);
        }

        public void Next()
        {
            BaseNext(this);
        }

        public void Play()
        {
            BasePlay(this);
        }

        public void Previous()
        {
            BasePrevious(this);
        }

        public void Rewind()
        {
            BaseRewind(this);
        }

        public void Stop()
        {
            BaseStop(this);
        }
    }
}
