﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task6.Interface
{
    public interface IPlayer
    {
        ISong CurrentSong { get; set; }
        IList<ISong> Songs { get; set; }
        void Play();
        void Stop();
        void Forward();
        void Rewind();
        void Next();
        void Previous();
        void AddSongs(ISong song);
    }
}
