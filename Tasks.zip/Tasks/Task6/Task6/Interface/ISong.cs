﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task6.Interface
{
    public interface ISong
    {
        string SongName { get; set; }
        string MovieName { get; set; }
        void Run();
        void Stop();
        void MoveFiveSecondsForward();
        void MoveFiveSecondsBackward();
    }
}
