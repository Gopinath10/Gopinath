﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Task3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Create
        private void button1_Click(object sender, EventArgs e)
        {
            File.Create(textBox1.Text).Dispose();
            MessageBox.Show("Done", "File Transactions");
            textBox5.Text = textBox1.Text;
            textBox1.Enabled = false;
        }
        // Write
        private async void button2_Click(object sender, EventArgs e)
        {
            if (File.Exists(textBox1.Text))
            {
                if (string.IsNullOrWhiteSpace(textBox2.Text) == false)
                {
                    StreamWriter wr = new StreamWriter(textBox1.Text);
                    await wr.WriteAsync(textBox2.Text);
                    wr.Dispose();

                    textBox2.Text = string.Empty;
                    MessageBox.Show("Done", "File Transactions");
                }
                else
                {
                    MessageBox.Show("Please enter text in the text box");
                }
            }
            else
            {
                MessageBox.Show("File does not exist.");
            }
        }

        //Update
        private async void button3_Click(object sender, EventArgs e)
        {
            if (File.Exists(textBox1.Text))
            {
                if (string.IsNullOrWhiteSpace(textBox3.Text) == false)
                {

                    StreamWriter writer = new StreamWriter(textBox1.Text,true);
                    await writer.WriteAsync(textBox3.Text);
                    writer.Dispose();
                    textBox3.Text = string.Empty;
                    MessageBox.Show("Done", "File Transactions");
                }
                else
                {
                    MessageBox.Show("Please enter text in the text box");
                }
            }
            else
            {
                MessageBox.Show("File does not exist.");
            }
        }

        //Read
        private async void button4_Click(object sender, EventArgs e)
        {
            if (File.Exists(textBox1.Text))
            {
                StreamReader reader = new StreamReader(textBox1.Text);
                
                textBox4.Text = await reader.ReadToEndAsync();

                reader.Dispose();
            }
            else
            {
                MessageBox.Show("File does not exist.");
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (File.Exists(textBox5.Text))
            {
                File.Delete(textBox5.Text);
                textBox5.Text = string.Empty;
                MessageBox.Show("Done", "File Transactions");
            }
            else
            {
                MessageBox.Show("File does not exist.");
            }
        }
    }
}
