﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task1B
{
    class Program
    {
        static void Main(string[] args)
        {
            bool isExit = true;

            while (isExit)
            {
                Console.WriteLine("Enter a value :");
                string value = Console.ReadLine();
                Enums outputEnum = Enums.Zero ;
                bool isEnum = Enum.TryParse<Enums>(value, out outputEnum);
                
                if (isEnum)
                {
                    Console.WriteLine("Conveted value is : {0}", (Enums)Enum.Parse(typeof(Enums),value,true));
                    Console.ReadLine();
                    isExit = false;
                }
                else
                {
                    Console.WriteLine("Please enter valid data.");
                }
            }
        }
    }

    public enum Enums
    {
        Zero = 0,
        One = 1,
        Two = 2,
        Three = 3,
        Four = 4,
        Five = 5,
        Six = 6,
        Seven = 7,
        Eight = 8,
        Nine = 9
    }
}
