﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task1A
{
    class Program
    {
        static void Main(string[] args)
        {
            bool isExit = true;

            while (isExit)
            {
                Console.WriteLine("Enter a number :");
                string value = Console.ReadLine();
                int output = 0;
                bool isInteger = int.TryParse(value, out output);

                if (isInteger)
                {
                    Console.WriteLine("Conveted value is : {0}", Convert.ToInt32(value));
                    Console.ReadLine();
                    isExit = false;
                }
                else
                {
                    Console.WriteLine("Please enter valid data.");
                }
            }
        }
    }
}
