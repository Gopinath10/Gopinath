﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task1C
{
    class Program
    {
        static void Main(string[] args)
        {
            bool isExit = true;

            while (isExit)
            {
                Console.WriteLine("Enter a date :");
                string value = Console.ReadLine();
                DateTime output = DateTime.MinValue;
                bool isInteger = DateTime.TryParse(value, out output);

                if (isInteger)
                {
                    Console.WriteLine("Conveted value is : {0}", Convert.ToDateTime(value).ToString("dd-MMM-yyyy"));
                    Console.ReadLine();
                    isExit = false;
                }
                else
                {
                    Console.WriteLine("Please enter valid data.");
                }
            }
        }
    }
}
