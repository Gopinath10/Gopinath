﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Task7
{
    public class Services
    {
        string location = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location) + Path.DirectorySeparatorChar + "Database.xml";
        Datacontext datacontext = new Datacontext();

        public Services()
        {
            datacontext.AllEmployees = GetExistingEmployees(location );
        }

        public async Task<bool> CreateNewEmployee(Employee employee)
        {
            bool isSuccess = false;

            isSuccess = await Task.Run<bool>(new Func<bool>(() => {

                XmlSerializer lobjSerializer = new XmlSerializer(typeof(List<Employee>));

                datacontext.AllEmployees.Add(employee);

                using (TextWriter lobjWriter = new StreamWriter(location))
                {
                    lobjSerializer.Serialize(lobjWriter, datacontext.AllEmployees);
                    lobjWriter.Dispose();
                    isSuccess = true;
                }

                return isSuccess;

                //SqlConnection connection = new SqlConnection("connection string");

                //SqlCommand command = new SqlCommand("insert (id,name,address,phonenumber) into Employee(" + employee.Id + "," + employee.Name + "," + employee.Address + "," + employee.PhoneNumber + ")",connection);

                //command.CommandType = System.Data.CommandType.Text;

                ////command.CommandType = System.Data.CommandType.StoredProcedure;

                ////SqlParameter parameter = new SqlParameter();

                ////parameter.DbType = System.Data.DbType.DateTime;
                ////parameter.Size = 100;
                ////parameter.Value = employee.Name;
                ////parameter.ParameterName = "@Name";

                ////command.Parameters.Add(parameter);

                //int output = command.ExecuteNonQuery();
            }));
            
            return isSuccess;
        }

        public async  Task<string> UpdateEmployee(Employee employee)
        {
            string output = string.Empty;

            output = await Task.Run<string>(new Func<string>(() =>
            {
                XmlSerializer lobjSerializer = new XmlSerializer(typeof(List<Employee>));

                Employee employeeToUpdate = datacontext.AllEmployees.Where(a => a.Id == employee.Id).FirstOrDefault();

                if (employeeToUpdate != null)
                {
                    datacontext.AllEmployees.Remove(employeeToUpdate);
                    datacontext.AllEmployees.Add(employee);

                    using (TextWriter lobjWriter = new StreamWriter(location))
                    {
                        lobjSerializer.Serialize(lobjWriter, datacontext.AllEmployees);
                        lobjWriter.Dispose();
                    }
                }
                else output = "Employee not found";

                return output;
            }));
            
            return output;
        }

        public string Delete(int employeeId)
        {
            string output = string.Empty;

            XmlSerializer lobjSerializer = new XmlSerializer(typeof(List<Employee>));

            Employee employeeToUpdate = datacontext.AllEmployees.Where(a => a.Id == employeeId).FirstOrDefault();

            if (employeeToUpdate != null)
            {
                datacontext.AllEmployees.Remove(employeeToUpdate);

                using (TextWriter lobjWriter = new StreamWriter(location))
                {
                    lobjSerializer.Serialize(lobjWriter, datacontext.AllEmployees);
                    lobjWriter.Dispose();
                }
            }
            else output = "Employee not found";

            return output;
        }

        public List<Employee> ReadAllEmployees(string text)
        {
            List<Employee> filteredEmployee = new List<Employee>();

            if (string.IsNullOrWhiteSpace(text))
            {
                filteredEmployee = GetExistingEmployees(location);
            }
            else
            {
                filteredEmployee = GetExistingEmployees(location).Where(a => a.Name.Contains(text)).ToList();
            }
            return filteredEmployee;
        }
        public List<Employee> GetExistingEmployees(string pstrLocation)
        {
            List<Employee> lcolEmployees = new List<Employee>();

            XmlSerializer lobjDeserialize = new XmlSerializer(typeof(List<Employee>));
            TextReader lobjReader = new StreamReader(pstrLocation);

            lcolEmployees = (List<Employee>)lobjDeserialize.Deserialize(lobjReader);

            lobjReader.Dispose();

            return lcolEmployees;
        }

    }
}
