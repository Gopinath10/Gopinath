﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Task7
{
    public partial class Form1 : Form
    {
        Services service = new Services();
        
        public Form1()
        {
            InitializeComponent();

            textBox1.Enabled = false;
            textBox1.Text = (new Random().Next(0, 10000)).ToString();
        }

        private async void button1_Click(object sender, EventArgs e)
        {
            string id = textBox1.Text;
            string name = textBox2.Text;
            string address = textBox3.Text;
            string phoneNumber = textBox4.Text;

            Employee employee = new Employee();

            employee.Id = Convert.ToInt32(id);
            employee.Name = name;
            employee.Address = address;
            employee.PhoneNumber = phoneNumber;

            bool isSucess = await service.CreateNewEmployee(employee);

            if (isSucess)
            {
                MessageBox.Show("Saved successfully");
                button2_Click(null, null);
                textBox1.Text = (new Random().Next(0, 10000)).ToString();
            }
            else
            {
                MessageBox.Show("Error while saving data");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text = string.Empty;
            textBox2.Text = string.Empty;
            textBox3.Text = string.Empty;
            textBox4.Text = string.Empty;
        }

        private async void button4_Click(object sender, EventArgs e)
        {
            string id = UpdateId.Text;
            string name = UpdateName.Text ;
            string address = UpdateAddress.Text;
            string phoneNumber  = UpdatePhoneNumber.Text  ;

            Employee employee = new Employee();

            employee.Id = Convert.ToInt32(id);
            employee.Name = name;
            employee.Address = address;
            employee.PhoneNumber = phoneNumber;

            string output = await service.UpdateEmployee(employee);

            if (string.IsNullOrWhiteSpace(output))
            {
                MessageBox.Show("Updated successfully");
                button3_Click(null, null);
            }
            else if (output == "Employee not found")
            {
                MessageBox.Show("Employee not found");
            }
            else
            {
                MessageBox.Show("Error while saving data");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            UpdatePhoneNumber.Text = string.Empty;
            UpdateAddress.Text = string.Empty;
            UpdateName.Text = string.Empty;
            UpdateId.Text = string.Empty;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            string text = SearchText.Text;
            
            dataGridView1.DataSource = service.ReadAllEmployees(text);

        }

        private void button6_Click(object sender, EventArgs e)
        {
            string id = deleteText.Text;
            string output = string.Empty;
            if (string.IsNullOrWhiteSpace(id)) MessageBox.Show("Please enter employee id");
            else output = service.Delete(Convert.ToInt32(id));

            if (string.IsNullOrWhiteSpace(output))
            {
                MessageBox.Show("Deleted successfully");
             
            }
            else if (output == "Employee not found")
            {
                MessageBox.Show("Employee not found");
            }
            else
            {
                MessageBox.Show("Error while saving data");
            }
        }
    }
}
