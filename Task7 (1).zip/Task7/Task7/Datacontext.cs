﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task7
{
    public class Datacontext
    {
        public Datacontext()
        {
            AllEmployees = new List<Employee>();

        }

        private List<Employee> allEmployees;

        public List<Employee> AllEmployees
        {
            get { return allEmployees; }
            set { allEmployees = value; }
        }
    }
}
