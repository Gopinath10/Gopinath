﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace API.Controllers
{
    public class EmployeeController : ApiController
    {
        public string Get()
        {
            return "Get is Called";
        }

        public string Post()
        {
            return "Post is Called";
        }

        public string Put()
        {
            return "Put is Called";
        }

        public string Delete()
        {
            return "Delete is Called";
        }
    }
}
