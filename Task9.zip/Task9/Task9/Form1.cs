﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Task9
{
    public partial class Form1 : Form
    {
        HttpClient client = new HttpClient();

        public Form1()
        {
            InitializeComponent();
        }

        private async void button1_Click(object sender, EventArgs e)
        {
            
            var getValue = await client.GetAsync(new Uri("http://localhost:62765/api/Employee"));

            MessageBox.Show(await getValue.Content.ReadAsStringAsync());
        }

        private async void button2_Click(object sender, EventArgs e)
        {
            StringContent content = new StringContent("", Encoding.UTF8, "application/json");

            HttpResponseMessage response = await client.PostAsync(new Uri("http://localhost:62765/api/Employee"), content);

            MessageBox.Show(await response.Content.ReadAsStringAsync());
        }

        private async void button3_Click(object sender, EventArgs e)
        {
            StringContent content = new StringContent("", Encoding.UTF8, "application/json");

            HttpResponseMessage response = await client.PutAsync(new Uri("http://localhost:62765/api/Employee"), content);

            MessageBox.Show(await response.Content.ReadAsStringAsync());
        }

        private async void button4_Click(object sender, EventArgs e)
        {
            HttpResponseMessage response = await client.DeleteAsync(new Uri("http://localhost:62765/api/Employee"));

            MessageBox.Show(await response.Content.ReadAsStringAsync());
        }
    }
}
